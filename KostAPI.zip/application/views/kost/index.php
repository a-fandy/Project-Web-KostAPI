<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <link href="<?php echo base_url();?>assets/cover.css" rel="stylesheet">    
<title>Daftar Kost</title>
</head>

<body class="text-center">

<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="masthead mb-auto">
    <div class="inner">
      <h3 class="masthead-brand">API KOST</h3>
      <nav class="nav nav-masthead justify-content-center">
        <a class="nav-link active" href="#">Home</a>
        <!-- <a class="nav-link" href="#">Features</a>
        <a class="nav-link" href="#">Contact</a> -->
      </nav>
    </div>
  </header>

  <main role="main" class="inner cover">
    <h1 class="cover-heading">Golek Kost</h1>
    <p class="lead"> GET / POST: <a href="<?php echo base_url();?>Kost/481f4b73e27afd9fd9"> <?php echo base_url();?>Kost/481f4b73e27afd9fd9 </a> </p>
    <p>Parameter</p>
    <p>Get : null / idKost</p>
    <p>Post:tersedia,namaKost,alamat,noTelp,namaPemilik,ukuran,jenis,harga,gambar,deskripsi</p>
    <p class="lead">
      <a href="http://golekkost.000webhostapp.com/" class="btn btn-lg btn-secondary">Golek Kost</a>
    </p>
  </main>

  <table class="table table-bordered">
  <thead>
    <tr>
        <th scope="col">NamaKost</th>
        <th scope="col">Alamat</th>
        <th scope="col">NoTelp</th>
        <th scope="col">NamaPemilik</th>
        <th scope="col">Ukuran</th>
        <th scope="col">Jenis</th>
        <th scope="col">Harga</th>   
    </tr>
  </thead>
  <tbody>
    <?php 
        foreach($kost as $k){
             ?>
        <tr>
            <th scope="row"><?php echo $k->namaKost; ?></th>
            <td><?php echo $k->alamat; ?></td>
            <td><?php echo $k->noTelp; ?></td>
            <td><?php echo $k->namaPemilik; ?></td>
            <td><?php echo $k->ukuran; ?></td>
            <td><?php echo $k->jenis; ?></td>
            <td><?php echo $k->harga; ?></td>
           
        </tr>
        <?php } ?>
  </tbody>
</table>

  <footer class="mastfoot mt-auto">
    <div class="inner">
      <p>API Server by Fandy</p>
    </div>
  </footer>
</div>


<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script>window.jQuery || document.write('<script src="http://localhost/KostAPI/application/asset/jquery-slim.min.js"><\/script>')</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

</body>
</html>